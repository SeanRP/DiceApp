package com.einfo3245.diceProject;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.drawable.AnimationDrawable;
import android.graphics.drawable.Drawable;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.view.View;
import android.view.animation.Animation;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;

import java.text.DecimalFormat;
import java.util.Random;

public class D20 extends AppCompatActivity {

    int roll;
    int sum,i;
    boolean isTrue = false;
    MediaPlayer mRollSound;



    AnimationDrawable diceAnimation;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_d20);



        //this is for the animation of the dice rolling
        // final ImageView imgFrame = (ImageView)findViewById(R.id.animationRollingD4);
        //imgFrame.setBackgroundResource(R.drawable.animationd4);
        // diceAnimation = (AnimationDrawable)imgFrame.getBackground();


        //animation uses this button too!
        Button cost = (Button) findViewById(R.id.buttonDiceResultD20);
        final ImageView imgFrame = (ImageView)findViewById(R.id.animationRollingD20);
        imgFrame.setBackgroundResource(R.drawable.animationd20);
        diceAnimation = (AnimationDrawable)imgFrame.getBackground();

        //for the sound
        mRollSound = new MediaPlayer();
        mRollSound = MediaPlayer.create(this, R.raw.dice_roll_sound);

        cost.setOnClickListener(new View.OnClickListener() {
            //this allows to change the textview
            final TextView outputTotal = (TextView) findViewById(R.id.resultTitleD20);
            final TextView outputRolls = (TextView) findViewById(R.id.rollsTitleD20 );




            @Override
            public void onClick(View view) {

                //sound
                mRollSound.start();

                //onClick
                imgFrame.setBackgroundResource(R.drawable.animationd20);
                diceAnimation = (AnimationDrawable)imgFrame.getBackground();

                //calculation is over time for the animation
                diceAnimation.start();



                //Get spinner selection
                final Spinner userInputSpinner = (Spinner) findViewById(R.id.spinnerD20);
                //this will store the number of dice
                int numberOfDice = Integer.parseInt(userInputSpinner.getSelectedItem().toString());

                //initilizing the array
                StringBuilder builder = new StringBuilder();
                //this was made final by the String result = rollsArray[0]
                final String [] rollsArray = new String[numberOfDice];

                //this loop will generate a random number based on the number of dice selected
                for (i = 0; i < numberOfDice; i++) {
                    //this is the randomizer part
                    final int randomNumber = new Random().nextInt(20) + 1;
                    //this will store the current roll
                    roll = randomNumber;
                    //this array will store all the rolls
                    rollsArray[i] = Integer.toString(roll);
                    //this sum will add up all the rolls
                    sum += roll;
                }
                //  this will output the stored rolls in the array to the TextView
                for (String s : rollsArray) {

                    String diceRolls = "Dice Rolls: ";
                    //add comma if more than one dice
                    if(numberOfDice > 1){
                        builder.append(s).append(", ");
                    }
                    //else no comma
                    else{
                        builder.append(s).append(" ");
                    }

                    //formatting the output so we can concatenate the strings
                    outputRolls.setText(String.format("%s%s", diceRolls, builder.toString()));
                }


                //this will output the sum of the rolls
                DecimalFormat diceFormat = new DecimalFormat("###");
                // I had to format the output to get it on one line
                //the setText method doesn't like it when we try to concatenate the Strings together
                diceFormat.format(sum);
                String diceTotal = "Dice Total: ";
                //Concatenate string
                diceTotal += sum;
                outputTotal.setText(diceTotal);

                sum = 0;




                //I want to make it so based on the first roll the number on the dice will show up
                //ex. roll a 1, after the animation the image of a d4 with a 1 shows up

                new CountDownTimer(640,1000) {

                    public void onTick(long millisUntilFinished) {

                    }
                    public void onFinish() {
                        //set image
                        ImageView resultImage = (ImageView) findViewById(R.id.animationRollingD20);
                        String result = rollsArray[0];
                        String result2 = "d20_" + result;

                        int diceId = getResources().getIdentifier(result2, "drawable", getPackageName());
                        resultImage.setBackgroundResource(diceId);


                    }
                }.start();











            }


        });




    }
}