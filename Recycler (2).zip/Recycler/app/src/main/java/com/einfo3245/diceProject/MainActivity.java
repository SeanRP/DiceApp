package com.einfo3245.diceProject;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.SharedPreferences;
import android.os.Bundle;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {


    RecyclerView mRecyclerView;
    MyAdapter myAdapter;

    SharedPreferences preferences;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mRecyclerView = findViewById(R.id.recyclerView);

        preferences = this.getSharedPreferences("My_Pref", MODE_PRIVATE);

        getMyList();

    }


    private void getMyList() {

        ArrayList<Model> models = new ArrayList<>();

        Model m = new Model();
        m.setTitle("D4");
        m.setImg(R.drawable.d4);
        models.add(m);

        m = new Model();
        m.setTitle("D6");
        m.setImg(R.drawable.d6);
        models.add(m);

        m = new Model();
        m.setTitle("D8");
        m.setImg(R.drawable.d8);
        models.add(m);

        m = new Model();
        m.setTitle("D10");
        m.setImg(R.drawable.d10);
        models.add(m);

        m = new Model();
        m.setTitle("D12");
        m.setImg(R.drawable.d12);
        models.add(m);

        m = new Model();
        m.setTitle("D20");
        m.setImg(R.drawable.d20);
        models.add(m);


        mRecyclerView.setLayoutManager(new LinearLayoutManager(this));

        myAdapter = new MyAdapter(this, models);
        mRecyclerView.setAdapter(myAdapter);


    }

}