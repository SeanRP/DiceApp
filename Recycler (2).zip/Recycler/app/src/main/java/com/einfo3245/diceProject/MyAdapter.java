package com.einfo3245.diceProject;


import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Filter;
import android.widget.Filterable;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class MyAdapter extends RecyclerView.Adapter<MyHolder> implements Filterable {

    Context c;
    ArrayList<Model> models, filterList;
    CustomFilter filter;

    public MyAdapter(Context c, ArrayList<Model> models) {
        this.c = c;
        this.models = models;
        this.filterList = models;
    }

    @NonNull
    @Override
    public MyHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {

        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.row, null);

        return new MyHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull final MyHolder myHolder, int i) {

        myHolder.mTitle.setText(models.get(i).getTitle());
        myHolder.mImaeView.setImageResource(models.get(i).getImg());


        /*myHolder.setItemClickListener(new ItemClickListener() {
            @Override
            public void onItemClickListener(View v, int position) {

                String gTitle = models.get(position).getTitle();
                BitmapDrawable bitmapDrawable = (BitmapDrawable)myHolder.mImaeView.getDrawable();

                Bitmap bitmap = bitmapDrawable.getBitmap();

                ByteArrayOutputStream stream = new ByteArrayOutputStream();

                bitmap.compress(Bitmap.CompressFormat.PNG, 100,stream);

                byte[] bytes = stream.toByteArray();

                Intent intent = new Intent(c, AnotherActivity.class);
                intent.putExtra("iTitle", gTitle);
                intent.putExtra("iImage", bytes);
                c.startActivity(intent);
            }
        });*/

        myHolder.setItemClickListener(new ItemClickListener() {
            @Override
            public void onItemClickListener(View v, int position) {

                if (models.get(position).getTitle().equals("D4")) {
                    Intent intent = new Intent(c, D4.class);
                    c.startActivity(intent);
                }

                if (models.get(position).getTitle().equals("D6")) {
                    Intent intent = new Intent(c, D6.class);
                    c.startActivity(intent);
                }

                if (models.get(position).getTitle().equals("D8")) {
                    //then you can move another activity from if body
                    Intent intent = new Intent(c, D8.class);
                    c.startActivity(intent);
                }

                if (models.get(position).getTitle().equals("D10")) {
                    //then you can move another activity from if body
                    Intent intent = new Intent(c, D10.class);
                    c.startActivity(intent);
                }

                if (models.get(position).getTitle().equals("D12")) {
                    //then you can move another activity from if body
                    Intent intent = new Intent(c, D12.class);
                    c.startActivity(intent);
                }

                if (models.get(position).getTitle().equals("D20")) {
                    //then you can move another activity from if body
                    Intent intent = new Intent(c, D20.class);
                    c.startActivity(intent);
                }

            }
        });

    }

    @Override
    public int getItemCount() {
        return models.size();
    }

    @Override
    public Filter getFilter() {

        if (filter ==null){
            filter = new CustomFilter(filterList, this);
        }

        return filter;

    }
}
